import React from 'react';
import Navbar from './components/Navbar'
import Carousel from './components/Carousel'
import WebSites from './components/WebSites'
import Conocimientos from './components/conocimientos'

class App extends React.Component{
  constructor(props){
    super(props)
    this.state = {
      paginas:[],
      conocimientos:[],
      descripcion:""
    }
  }
  componentDidMount = () =>{
    fetch("https://my-json-server.typicode.com/KumanEnrique/paginas-web/db")
      .then(repuesta=>repuesta.json())
      .then(resultado=>{
        this.setState({
          paginas:resultado.paginas
        })
      })
    fetch("https://my-json-server.typicode.com/KumanEnrique/paginas-web/db")
      .then(repuesta=>repuesta.json())
      .then(resultado=>{
        this.setState({
          conocimientos:resultado.conocimientos
        })
      })
    fetch("https://my-json-server.typicode.com/KumanEnrique/paginas-web/db")
      .then(repuesta=>repuesta.json())
      .then(resultado=>{
        this.setState({
          descripcion:resultado.descripcion[0]
        })
      })
  }
  render(){
    return(
      <div className="App">
        <Navbar></Navbar>
        <Carousel></Carousel>
        <div className="container mt-3" id="portafolio">
          <div className="row">
          {this.state.paginas.map((ele,index)=>{
          return <WebSites elemento={ele} key={index}></WebSites>
        })}
          </div>
        </div>

        <div className="container mt-3" id="conocimiento">
          <div className="row">
            <div className="col-6">
              <h3>¿Quien soy?</h3>
              {this.state.descripcion}
            </div>
            <div className="col-6 ">
              <h3>Conocimientos</h3>
              {this.state.conocimientos.map((ele,index)=>{
              return <Conocimientos key={index} elemento={ele}></Conocimientos>
            })}
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default App;
