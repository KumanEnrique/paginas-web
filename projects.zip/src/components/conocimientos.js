import React from 'react'

function Conocimientos (props){
    return(
        <>
        <span className="badge badge-pill badge-success">{props.elemento}</span>
        </>
    )
}
export default Conocimientos