import React from 'react'

function Carousel (){
    return(
        <div className="container mt-2">
            <div id="carouselExampleInterval" className="carousel slide" data-ride="carousel">
                <div className="carousel-inner">
                    <div className="carousel-item active" data-interval="5000">
                        <img src="imagenes/2.png" className="img-fluid" alt="Responsive " />
                    </div>
                    <div className="carousel-item" data-interval="2000">
                        <img src="imagenes/4.png" className="img-fluid" alt="Responsive " />
                    </div>
                    <div className="carousel-item">
                        <img src="imagenes/10.png" className="img-fluid" alt="Responsive " />
                    </div>
                </div>
                <a className="carousel-control-prev" href="#carouselExampleInterval" role="button" data-slide="prev">
                    <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                </a>
                <a className="carousel-control-next" href="#carouselExampleInterval" role="button" data-slide="next">
                    <span className="carousel-control-next-icon" aria-hidden="true"></span>
                </a>
            </div>
        </div>
    )
}
export default Carousel